import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class BasketTest {


    @Test
    public void addItemToBasket() throws InterruptedException {

        String expectedTitle = "Jeans";
        CommonUtility.searchAnItemByProductOrBrandName("Jeans", expectedTitle);

        List<WebElement> listOfItems = CommonUtility.driver.findElements(By.xpath("//div[@id='rhs']/div[5]/article/section/div[1]/h2/a"));

        String itemToChoose = "Mid Blue Slim Fit Authentic Stretch Jeans";

        Thread.sleep(5000);
        CommonUtility.clickProductFromListOfItem(listOfItems, itemToChoose);

        CommonUtility.driver.findElement(By.id("dk_container_Colour-209765")).click();
        List<WebElement> listOfColours = CommonUtility.driver.findElements(By.xpath("//div[@id='dk_container_Colour-209765']/div/ul/li"));

        String color = "Black";
        CommonUtility.selectValueFromDivisionTag(listOfColours, color);
        CommonUtility.driver.findElement(By.xpath("//div[@id='dk_container_Fit-209765']/a")).click();
        List<WebElement> listOfFit = CommonUtility.driver.findElements(By.xpath("//div[@id='dk_container_Fit-209765']/div/ul/li"));
        String fitOption = "Slim Fit";
        CommonUtility.selectValueFromDivisionTag(listOfFit, fitOption);

        Thread.sleep(5000);
        WebElement element = CommonUtility.driver.findElement(By.linkText("Choose Size"));
        CommonUtility.clickJS(element);
        /*
         * List<WebElement> listOfSize = driver.findElements(By.xpath("//div[@id='dk_container_Size-530-205']/div/ul/li"));
         * String sizeOption = "32 S";
         * SelectValueFromDivisionTag(listOfSize, sizeOption);
         */
        CommonUtility.driver.findElement(By.linkText("30 S")).click();

        CommonUtility.driver.findElement(By.xpath("//div[@class='BagHolder padding-top-10']/div/a")).click();
        Thread.sleep(5000);
        String actualCount = CommonUtility.driver.findElement(By.xpath("//section[@class='BagSummary MiniBagNonSecure']/a/div/div/span")).getText();
        int actualNoOfItem = CommonUtility.getNumber(actualCount);
        int expectedNoOfItem = CommonUtility.getNumber("1");
        Assert.assertEquals(expectedNoOfItem, actualNoOfItem);

    }



}
